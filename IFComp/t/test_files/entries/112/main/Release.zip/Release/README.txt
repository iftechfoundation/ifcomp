This file represents some extra content, which only people downloading the game and browsing its files offline would see! People playing the game online via ifcomp.org would not see it at all.

Interesting.
